<script setup>
import { ref, onMounted, computed } from 'vue'
import ImageCard from '../components/ImageCard.vue'
import Lightbox from '../components/Lightbox.vue'

const searchText = ref('')
const images = ref([])
const filteredImages = ref([])
const lightboxOpen = ref(false)
const currentIndex = ref(0)

// Lapozás változók
const currentPage = ref(1)
const imagesPerPage = ref(8) 
onMounted(async () => {
  const resp = await fetch('http://localhost:3000/pics')
  images.value = await resp.json()
  filteredImages.value = images.value
})

function onSearch() {
  const query = searchText.value.replace('#', '').toLowerCase().trim()
  
  // Keresés után visszaugrik az első oldalra
  currentPage.value = 1
  
  if (!query) {
    filteredImages.value = images.value
    return
  }
  
  filteredImages.value = images.value.filter(img => {
    const authorMatch = img.author?.toLowerCase().includes(query)
    
    const tagsMatch = img.tags?.some(tag => {
      const cleanTag = tag.replace('#', '').toLowerCase()
      return cleanTag.includes(query)
    })
    
    return authorMatch || tagsMatch
  })
}

// Aktuális oldal képeinek kiszámítása
const paginatedImages = computed(() => {
  const start = (currentPage.value - 1) * imagesPerPage.value
  const end = start + imagesPerPage.value
  return filteredImages.value.slice(start, end)
})

// Összes oldal száma
const totalPages = computed(() => {
  return Math.ceil(filteredImages.value.length / imagesPerPage.value)
})

// Lapozó gombok
function goToPage(page) {
  currentPage.value = page
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function previousPage() {
  if (currentPage.value > 1) {
    currentPage.value--
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
}

// Látható oldalszámok (max 5 gomb)
const visiblePages = computed(() => {
  const pages = []
  const total = totalPages.value
  const current = currentPage.value
  
  if (total <= 5) {
    for (let i = 1; i <= total; i++) {
      pages.push(i)
    }
  } else {
    if (current <= 3) {
      pages.push(1, 2, 3, 4, '...', total)
    } else if (current >= total - 2) {
      pages.push(1, '...', total - 3, total - 2, total - 1, total)
    } else {
      pages.push(1, '...', current - 1, current, current + 1, '...', total)
    }
  }
  
  return pages
})

function openLightbox(index) {

  const globalIndex = (currentPage.value - 1) * imagesPerPage.value + index
  currentIndex.value = globalIndex
  lightboxOpen.value = true
}
</script>

<template>
  <form @submit.prevent="onSearch" class="flex items-center gap-2 max-w-md mx-auto my-8">
    <input
      v-model="searchText"
      type="text"
      placeholder="Keresés... "
      class="border border-gray-300 rounded px-4 py-2 flex-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
    <button
      type="submit"
      class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
    >
      Keresés
    </button>
  </form>

  <div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6 text-center">Vue Tailwind Image Gallery</h1>

    <!-- Találatok száma -->
    <div v-if="searchText" class="text-center text-gray-600 mb-4">
      {{ filteredImages.length }} találat "{{ searchText }}" keresésre
      <span v-if="totalPages > 1"> - {{ currentPage }}. oldal / {{ totalPages }}</span>
    </div>

    <!-- Ha nincs találat -->
    <div v-if="searchText && filteredImages.length === 0" class="text-center text-gray-500 mt-8 text-xl">
      😔 Nincs találat a "{{ searchText }}" keresésre
    </div>

    <!-- Képek grid -->
    <div v-else class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <ImageCard
        v-for="(img, index) in paginatedImages"
        :key="img.id"
        :image="img"
        @click="openLightbox(index)"
      />
    </div>

    <!-- Lapozó -->
    <div v-if="totalPages > 1" class="flex items-center justify-center gap-2 mt-8">
      <!-- Előző gomb -->
      <button
        @click="previousPage"
        :disabled="currentPage === 1"
        :class="[
          'px-4 py-2 rounded transition',
          currentPage === 1
            ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        ]"
      >
        ← Előző
      </button>

      <!-- Oldalszámok -->
      <button
        v-for="page in visiblePages"
        :key="page"
        @click="typeof page === 'number' ? goToPage(page) : null"
        :disabled="page === '...'"
        :class="[
          'px-4 py-2 rounded transition',
          page === currentPage
            ? 'bg-blue-600 text-white font-bold'
            : page === '...'
            ? 'bg-transparent text-gray-400 cursor-default'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        ]"
      >
        {{ page }}
      </button>

      <!-- Következő gomb -->
      <button
        @click="nextPage"
        :disabled="currentPage === totalPages"
        :class="[
          'px-4 py-2 rounded transition',
          currentPage === totalPages
            ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        ]"
      >
        Következő →
      </button>
    </div>

    <Lightbox
      v-if="lightboxOpen"
      :images="filteredImages"
      :startIndex="currentIndex"
      @close="lightboxOpen = false"
    />
  </div>
</template>