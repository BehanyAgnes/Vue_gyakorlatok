import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Books from '../views/Books.vue'
import Contact from '../views/Contact.vue'

const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/books', name: 'Books', component: Books },
  { path: '/contact', name: 'Contact', component: Contact },
   {path: '/', name: 'Hello', component: Home}
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
